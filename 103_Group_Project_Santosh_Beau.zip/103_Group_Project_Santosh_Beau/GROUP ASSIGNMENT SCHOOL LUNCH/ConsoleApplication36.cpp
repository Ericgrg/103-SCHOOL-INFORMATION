


/* NZ School Information System

1.Introduction screen should include :

School name

Contact details

Latest events or upcoming events details

Term dates

Login and registration options for parentsand teachers.

It can also be logged inand controlled by an administration account(See Task 3 for more details)

2.New teacher registration screen should include :

A Menu with the following options :

Registration: should have full name, gender, dob, email, contact number, classroom number, year they teach(e.g., year 1), usernameand password.

Login : should be verified against teacher_registration file

Provide Maximum three login attempts to access the system.Otherwise notify them to login after some time.

Creating student record should include : (See Task 5)

3.Admin screen includes :

Admin can access the class recordsand parent�s records.

Report of the students who need help

Report of the students who are in progressing state

The report should include, classroom number, student full name, learning progress of each subject, teacher nameand their parents contact number.

4. Parent registration screen should include

Full name, gender, dob, email, contact number, child full name or names, child classroom number, child parent / caregiver full name and the emergency contact number, username, and password.

Login should be verified against parent_registration file

Provide Maximum three login attempts to access the system.Otherwise notify them to login after some time.

Parents get options to view their children�s reportand the school notices.

5. Student record screen should include

Following menu options :

Add student

Edit student record

Delete student record

Update record(adding another term observation)

View the records

Student record should include the following fields,

Full name, gender, maths, science, writing, readingand Others(might be sports, art, music or friendly etc.) and Learning_Progress.

Learning progress could be measured by(Achieved, Progressing, Need Help).

Each class must have separate file to manage their data. (for e.g., Room_20)
*/




#include <iostream>
#include <string>
#include <fstream>
#include <conio.h>

using namespace std;

struct Teacher //structure for teacher record
{
    char full_name_t[50];
    string gender_t;
    string dob_t;
    string email_t;
    string contact_no_t;
    
    char username_t[20];
    char password_t[20];
};

struct Parent //structure for parent record
{
    char full_name_p[50];
    string gender_p;
    string dob_p;
    string email_p;
    string contact_no_p;
    char child_name_p[50];
    char caregiver_name_p[50];
    string emergency_no_p;
    char username_p[20];
    char password_p[20];
};

struct Student //structure for student record
{
    char full_name_s[50];
    string gender_s;
    string class_no_s;
    int maths;
    int science;
    int writing;
    int reading;
    string progress_maths;
    string progress_science;
    string progress_writing;
    string progress_reading;
    
};

//delcare global varialbe
fstream teacherFile, studentFile, ParentFile;
fstream class101, class102, class103;
struct Teacher newTeacher;
struct Student student;
struct Parent newParent;
char name[50];
char search_name[50];
int position = 0;

//declare function prototype
void line();
void school_name();
void contact_detail();
void latest_event();
void term_dates();
void teacher_screen();
void parent_screen();
void register_p();
void login_p();
void admin_screen();
void Admin_Dash();
void Class_Records();
void Parent_Page();
void parent_dash();
void report();
void register_t();
void login_t();
void student_screen();
void addStudent();
void editStudent(char[]);
void deleteStudent(char[]);
void displayStudent();
void school_notice();
string LearningProgress(int);
int main_menu();




int main()
{
    int option = 0;
    do
    {
        option = main_menu();

        switch (option)
        {
        case 1: { system("CLS");
            line();
            cout << "\tPORIRUA SCHOOL " << endl;
            line();
            _getch();
            break;
        }
        case 2: {
            contact_detail(); break;
        }
        case 3: {
            latest_event(); break;
        }
        case 4: {
            term_dates(); break;
        }
        case 5: {
            teacher_screen(); break;
        }
        case 6: {
            parent_screen(); break;
        }
        case 7: {
            admin_screen(); break;
        }
        case 8: {
            cout << "\nExiting the program...";
        }
        default:cout << "Please enter a value between 1 and 8.\n";
            break;
        }
        
    } while (option != 8);
}

void line(){ }


int main_menu()
{
    int option = 0;
    //system("CLS");
    cout << "\n\t\t\tWELCOME TO SCHOOL INFORMATION SYSTEM ";
    line();
    cout << "\n\t1) SCHOOL NAME ";
    cout << "\n\t2) CONTACT DETAILS";
    cout << "\n\t3) LATEST EVENTS";
    cout << "\n\t4) TERM DATES";
    cout << "\n\t5) TEACHER LOGIN AND REGISTRATION";
    cout << "\n\t6) PARENT LOGIN AND REGISTRATION ";
    cout << "\n\t7) ADMIN ";
    cout << "\n\t8) EXIT";
    cout << "\nPLEASE SELECT AN OPTION ? ";
    cin >> option;
    return option;  
}

void school_name()
{
    system("CLS");
    line();
    cout << "PORIRUA SCHOOL ";
    line();
    _getch();
}


void contact_detail()
{
    system("CLS");
    line();
    cout << "\tSCHOOL CONTACT DETAILS ";
    line();
    cout << "\n\tADDRESS: 1 AWARUA STREET, ELSDON, PORIRUA 5022";
    cout << "\n\tEMAIL: Poriruaschool@gmail.com";
    cout << "\n\tPHONE NUMBER : 04 2377460";
    line();
    _getch();
}

void latest_event()
{
    system("CLS");
    line();
    cout << "\n\tSCHOOL LATEST EVENTS LIST";
    line();
    cout << "\nSWIMMING DAY: 12 September 2022";
    cout << "\nDANCING DAY: 19 September 2022";
    cout << "\n SPORTS DAY : 22 September 2022";
    cout << "\n PARENTS DAY : 27 September 2022";
    line();
    _getch();
}

void term_dates()
{
    system("CLS");
    line();
    cout << "\n\t PORIRUA SCHOOL TERMS DATES\n";
    line();
    cout << "\tTERM 1  FROM 21 FEBRUARY TO 12 APRIL \n";

    cout << "\tTerm 2 FROM 28 APRIL TO 2 JUNE \n";

    cout << "\tTerm 3: 20 JUNE TO 3 OCTOBER \n";

    cout << "\tTerm 4: 17 OCTOBER TO 19 DECEMBER\n";

    line();
    _getch();
}

void teacher_screen()
{
    int choice = 0;
    do
    {
        //system("CLS");
        cout << "\n\tWelcome! Teacher!";
        line();
        cout << "\n\t1. New Teacher Registration";
        cout << "\n\t2. Teacher Login";
        line();
        cout << "\nEnter your choice: ";
        cin >> choice;
        switch (choice)
        {
        case 1: {
            register_t(); break;
        }
        case 2: {
            login_t(); break;
        }
        default:cout << "Please enter a value between 1 and 2.\n";
            break;
        }
    } while (choice == 1 || choice == 2);
}

void register_t()
{
    line();
    cout << "\t\tHello! Welcome to the teacher registration process";
    line();

    ofstream teacherFile;
    teacherFile.open("teacher.txt", ios::out | ios::app | ios::binary);

    if (teacherFile.is_open())
    {
        cin.ignore();
        cout << "\n\tEnter your full name: ";
        cin.getline(newTeacher.full_name_t, 50);
        cout << "\t what your gender: ";
        cin >> newTeacher.gender_t;
        cout << "\twhat your Date of Birth: ";
        cin >> newTeacher.dob_t;
        cout << "\tEmail address: ";
        cin >> newTeacher.email_t;
        cout << "\tContact Number: ";
        cin >> newTeacher.contact_no_t;

        cin.ignore();
        cout << "\tEnter your username: ";
        cin >> newTeacher.username_t;
        cout << "\tEnter your password: ";
        cin >> newTeacher.password_t;

        teacherFile << newTeacher.full_name_t << endl;
        teacherFile << newTeacher.gender_t << endl;
        teacherFile << newTeacher.dob_t << endl;
        teacherFile << newTeacher.email_t << endl;
        teacherFile << newTeacher.contact_no_t << endl;
        teacherFile << newTeacher.username_t << endl;
        teacherFile << newTeacher.password_t << endl;
    }

    teacherFile.close();
    line();
    cout << "\t\t\tRegistration Successful!!!";
    line();
    student_screen();
    _getch();
    system("CLS");
}

void login_t()
{

    char usernameSearch_t[20];
    char passwordSearch_t[20];
    int i = 0;
    bool isFound = false;
    do
    {
        cout << "\nEnter your username: ";
        cin >> usernameSearch_t;
        cout << "Enter your password: ";
        cin >> passwordSearch_t;

        ifstream teacherFile;
        teacherFile.open("teacher.txt", ios::in | ios::binary);

        //search for record
        if (teacherFile.is_open())
        {

            while (!teacherFile.eof())
            {
                teacherFile.getline(newTeacher.username_t, 20);
                teacherFile.getline(newTeacher.password_t, 20);

                //validate record
                if (strcmp(newTeacher.username_t, usernameSearch_t) == 0 && strcmp(newTeacher.password_t, passwordSearch_t) == 0)
                {
                    //if validated, lead to another screen - student screenis
                    isFound = true;
                    student_screen();//nested scenario, after login, show nested student record menu
                    break;
                }
                else
                {
                    isFound = false;
                }
            }
        }
        if (isFound == false && i < 2)
        {
            cout << "Invalid username and password, please try again...\n";
            _getch();
        }
        i++;
        teacherFile.close();

    } while (i < 3);

    if (i == 3 && isFound == false)
    {
        cout << "\nToo Many Attempts!!!Send you Back to Main Screen!!!Please try again later...\n";
        line();
        main();
    }

}

void student_screen()
{
    line();
    cout << "\tWelcome to Student Record Menu!" << endl;
    line();
    cout << "\n\t1. Add Student";
    cout << "\n\t2. Edit Student Record";
    cout << "\n\t3. Delete Student Record";
    cout << "\n\t4. Update Student Record";
    cout << "\n\t5. View the Records";
    cout << "\n\t6. Back to Main Menu";
    line();

    
    int choice;
    cout << "\nEnter your option: ";
    cin >> choice;
    switch (choice)
    {
    case 1: {
        addStudent();
        break;
    }
    case 2: {
        editStudent(search_name);
        break;
    }
    case 3: {
        deleteStudent(name);
        break;
    }
    case 4: {
        editStudent(search_name);
        break;
    }
    case 5: {
        displayStudent();
        break;
    }
    case 6: {
        main();
    }
    default:cout << "\nInvalid option, please choose between 1 and 5" << endl;
        break;
    }
}

void addStudent()
{
    int ClassSelection;
    bool StudentDone = false;

    do
    {
        line();
        cout << "\n\t\t\tWelcome to Add Student Record";
        line();
        cout << "\t1. Class 101\n";
        cout << "\t2. Class 102\n";
        cout << "\t3. Class 103\n";
        cout << "\t4. Return to previous page\n";
        cout << "Please enter your choice: ";
        cin >> ClassSelection;
        system("CLS");
        switch (ClassSelection)
        {
        case 1: {

            class101.open("class_101.txt", ios::out | ios::app | ios::binary);

            if (class101.is_open())
            {
                cin.ignore();
                cout << "\n\n\tWhat your full name? ";
                cout << "\n\t What your Gender? ";
                cout << "\n\t What your Maths Score ? ";
                cout << "\n\t What your Science Score ? ";
                cout << "\n\tWhat your Writing Score ? ";
                cout << "\n\tWhat your Reading Score ? ";

                (29, 2);
                cin.getline(student.full_name_s, 50);
                (41, 3);
                cin >> student.gender_s;
                (29, 4);
                cin >> student.maths;
                (30, 5);
                cin >> student.science;
                (30, 6);
                cin >> student.writing;
                (30, 7);
                cin >> student.reading;

                student.progress_maths = LearningProgress(student.maths);
                student.progress_science = LearningProgress(student.science);
                student.progress_writing = LearningProgress(student.writing);
                student.progress_reading = LearningProgress(student.reading);


                ofstream class101;
                class101.open("class_101.txt", ios::out | ios::app | ios::binary);

                class101 << "Full name: " << student.full_name_s;
                class101 << "    Gender: " << student.gender_s;
                class101 << "    Maths: " << student.progress_maths;
                class101 << "    Science: " << student.progress_science;
                class101 << "    Writing: " << student.progress_writing;
                class101 << "    Reading: " << student.progress_reading;
            }
            else
            {
                cout << "\nUnable to access file....\n";
                _getch();
                system("CLS");
            }
            class101.close();
            cout << "\nNew Student Record Added Successfully\n";
            break;
        }
        case 2: {

            class102.open("class_102.txt", ios::out | ios::app | ios::binary);

            if (class102.is_open())
            {
                cin.ignore();
                cout << "\n\n\tWhat your full name? ";
                cout << "\n\t What your Gender? ";
                cout << "\n\tWhat your Maths Score ? ";
                cout << "\n\tWhat your Science Score? ";
                cout << "\n\tWhat your Writing Score?  ";
                cout << "\n\tWhat your  Reading Score ? ";

                (29, 2);
                cin.getline(student.full_name_s, 50);
                (41, 3);
                cin >> student.gender_s;
                (29, 4);
                cin >> student.maths;
                (30, 5);
                cin >> student.science;
                (30, 6);
                cin >> student.writing;
                (30, 7);
                cin >> student.reading;


                student.progress_maths = LearningProgress(student.maths);
                student.progress_science = LearningProgress(student.science);
                student.progress_writing = LearningProgress(student.writing);
                student.progress_reading = LearningProgress(student.reading);



                //open file for writing
                ofstream class102;
                class102.open("class_102.txt", ios::out | ios::app | ios::binary);

                class102 << "Full name: " << student.full_name_s;
                class102 << "    Gender: " << student.gender_s;
                class102 << "    Maths: " << student.progress_maths;
                class102 << "    Science: " << student.progress_science;
                class102 << "    Writing: " << student.progress_writing;
                class102 << "    Reading: " << student.progress_reading;
                
                _getch();
            }
            else
            {
                cout << "\nUnable to access file....\n";
                _getch();
                system("CLS");
            }

            class102.close();
            cout << "\nNew Student Record Added Successfully\n";
            break;
        }
        case 3: {

            class103.open("class_103.txt", ios::out | ios::app | ios::binary);//open class101 file

            if (class103.is_open())
            {
                cin.ignore();
                cout << "\n\n\t What your full name? ";
                cout << "\n\tWhat your Gender? ";
                cout << "\n\tWhat your Maths Score ? ";
                cout << "\n\tWhat your Science Score ? ";
                cout << "\n\tWhat your Writing Score ? ";
                cout << "\n\tWhat your Reading Score ? ";

                (29, 2);
                cin.getline(student.full_name_s, 50);
                (41, 3);
                cin >> student.gender_s;
                (29, 4);
                cin >> student.maths;
                (30, 5);
                cin >> student.science;
                (30, 6);
                cin >> student.writing;
                (30, 7);
                cin >> student.reading;

                student.progress_maths = LearningProgress(student.maths);
                student.progress_science = LearningProgress(student.science);
                student.progress_writing = LearningProgress(student.writing);
                student.progress_reading = LearningProgress(student.reading);
                
                ofstream class103;
                class103.open("class_103.txt", ios::out | ios::app | ios::binary);

                class103 << "Full name: " << student.full_name_s;
                class103 << "    Gender: " << student.gender_s;
                class103 << "    Maths: " << student.progress_maths;
                class103 << "    Science: " << student.progress_science;
                class103 << "    Writing: " << student.progress_writing;
                class103 << "    Reading: " << student.progress_reading;
               
                _getch();
                system("CLS");
            }
            else
            {
                cout << "\nUnable to access file....\n";
                _getch();
                system("CLS");
            }

            class103.close();
            cout << "\nNew Student Record Added Successfully\n";
            break;
        }
        case 4: {
            StudentDone = true;
            student_screen();
        }
        default:cout << "\nPlease enter correct option.\n";
            _getch();
            system("CLS");
            break;
        }

    } while (!StudentDone);

}


void editStudent(char search_name[50])
{
    int edit_choice;
    bool edit_done = false;


    do
    {
        line();
        cout << "\n\t\t\tWelcome to Edit Student Record Page\n";
        line();
        cout << "\t\t\t1. Class 101\n";
        cout << "\t\t\t2. Class 102\n";
        cout << "\t\t\t3. Class 103\n";
        cout << "\t\t\t4. Return to previous page\n";
        cout << "Please enter your choice: ";
        cin >> edit_choice;

        switch (edit_choice)
        {
        case 1: {
            class101.open("class_101.txt", ios::in | ios::out | ios::binary);
            cout << "\n\tSearch Student in Class 101\n";
            cin.ignore();
            cout << "\n\tEnter Student Full Name: ";
            cin.getline(student.full_name_s, 50);

            if (class101.is_open())
            {
                while (!class101.eof())
                {
                    class101.read(reinterpret_cast<char*>(&student), sizeof(student));
                    position = class101.tellg();

                    if (strcmp(search_name, student.full_name_s) == 0)
                    {
                        cout << "\n\tRecord Found:\n";
                        line();
                        cout << "Full name: " << student.full_name_s;
                        cout << "    Gender: " << student.gender_s;
                        cout << "    Maths: " << student.progress_maths;
                        cout << "    Science: " << student.progress_science;
                        cout << "    Writing: " << student.progress_writing;
                        cout << "    Reading: " << student.progress_reading;
                        

                        class101.seekp(position = (sizeof(student)));
                        cout << "\n\n\tEdit Student Record";
                        cout << "\n\tPlease enter student Information";
                        cout << "\n\tWhat your Maths Score ? ";
                        cin >> student.maths;
                        cout << "\n\tWhat your Science Score ? ";
                        cin >> student.science;
                        cout << "\n\tWhat your Writing Score ? ";
                        cin >> student.writing;
                        cout << "\n\tWhat your Reading Score? ";
                        cin >> student.reading;

                        cout << "\n\n\tStudent Record Edit Successful\n";
                        class101.write(reinterpret_cast<char*>(&student), sizeof(student));
                        break;
                    }
                }
            }
            else
            {
                cout << "\nUnable to access file...";
            }
            class101.close();
            break;
        }
        case 2: {

            class102.open("class_102.txt", ios::in | ios::out | ios::binary);
            cout << "\n\tSearch Student in Class 102\n";
            cin.ignore();
            cout << "\n\tEnter Student Full Name: ";
            cin.getline(student.full_name_s, 50);

            if (class102.is_open())
            {
                while (!class102.eof())
                {
                    class102.read(reinterpret_cast<char*>(&student), sizeof(student));
                    position = class102.tellg();

                    if (strcmp(search_name, student.full_name_s) == 0)
                    {
                        cout << "\n\tRecord Found:\n";
                        line();
                        cout << "Full name: " << student.full_name_s;
                        cout << "    Gender: " << student.gender_s;
                        cout << "    Maths: " << student.progress_maths;
                        cout << "    Science: " << student.progress_science;
                        cout << "    Writing: " << student.progress_writing;
                        cout << "    Reading: " << student.progress_reading;
                       
                        class102.seekp(position = (sizeof(student)));
                        cout << "\n\n\tEdit Student Record";
                        cout << "\n\tPlease enter student Information";
                        cout << "\n\tWhat your Maths Score ? ";
                        cin >> student.maths;
                        cout << "\n\tWhat your Science Score ? ";
                        cin >> student.science;
                        cout << "\n\tWhat your Writing Score ? ";
                        cin >> student.writing;
                        cout << "\n\tWhat your Reading Score ? ";
                        cin >> student.reading;
                        

                        cout << "\n\n\tStudent Record Edit Successful\n";
                        class102.write(reinterpret_cast<char*>(&student), sizeof(student));
                        break;
                    }
                }
            }
            else
            {
                cout << "\nUnable to access file...";
            }
            class102.close();
            break;

        }
        case 3: {

            class103.open("class_103.txt", ios::in | ios::out | ios::binary);
            cout << "\n\tSearch Student in Class 103\n";
            cin.ignore();
            cout << "\n\tEnter Student Full Name: ";
            cin.getline(student.full_name_s, 50);

            if (class103.is_open())
            {
                while (!class103.eof())
                {
                    class103.read(reinterpret_cast<char*>(&student), sizeof(student));
                    position = class103.tellg();

                    if (strcmp(search_name, student.full_name_s) == 0)
                    {
                        cout << "\n\tRecord Found:\n";
                        line();
                        cout << "Full name: " << student.full_name_s;
                        cout << "    Gender: " << student.gender_s;
                        cout << "    Maths: " << student.progress_maths;
                        cout << "    Science: " << student.progress_science;
                        cout << "    Writing: " << student.progress_writing;
                        cout << "    Reading: " << student.progress_reading;
                       
                        class103.seekp(position = (sizeof(student)));
                        cout << "\n\n\tEdit Student Record";
                        cout << "\n\t enter student Information";
                        cout << "\n\tWhat your Maths Score ? ";
                        cin >> student.maths;
                        cout << "\n\tWhat your Science Score ? ";
                        cin >> student.science;
                        cout << "\n\tWhat your Writing Score ? ";
                        cin >> student.writing;
                        cout << "\n\tWhat your Reading Score ? ";
                        cin >> student.reading;


                        cout << "\n\n\tStudent Record Edit Successful\n";
                        class103.write(reinterpret_cast<char*>(&student), sizeof(student));
                        break;
                    }
                }
            }
            else
            {
                cout << "\nUnable to access file...";
            }
            class103.close();
            break;
        }
        case 4:edit_done = true;
        default:
            break;
        }

    } while (!edit_done);

}



void deleteStudent(char name[50])
{
    int choice;
    fstream tempfile;
    string line;
    bool delete_done = false;

    do
    {
        cout << "\n\n\t\t\tWelcome to Delete Student Record Page";
        cout << "\n\t\t\t1. Class 101";
        cout << "\n\t\t\t2. Class 102";
        cout << "\n\t\t\t3. Class 103";
        cout << "\n\t\t\t4. Return to previous page";
        cout << "\nPlease enter your choice: ";
        cin >> choice;
        //switch case to ask which file to edit

        switch (choice)
        {
        case 1: {
            cout << "\nPlease enter the name of student you want to delete: ";
            cin.ignore();
            cin.getline(name, 50);

            class101.open("class_101.txt", ios::in | ios::out | ios::binary);
            if (class101.is_open())
            {
                while (!class101.eof())
                {
                    while (class101.read(reinterpret_cast<char*>(&student), sizeof(student)))
                    {
                        if (strcmp(student.full_name_s, name) == 0)
                        {
                            cout << "\nRecord Found";
                            cout << "\nStudent Name: " << student.full_name_s;
                        }
                        else
                        {
                            tempfile.open("temp.txt", ios::out | ios::app | ios::binary);
                            tempfile.write(reinterpret_cast<char*>(&student), sizeof(student));
                            tempfile.close();
                        }
                    }
                }
            }
            class101.close();
            remove("class_101.txt");
            rename("temp.txt", "class_101.txt");
            break;

        }
        case 2: {

            cout << "\nPlease enter the name of student you want to delete: ";
            cin.ignore();
            cin.getline(name, 50);

            class102.open("class_102.txt", ios::in | ios::out | ios::binary);
            if (class102.is_open())
            {
                while (!class102.eof())
                {
                    while (class102.read(reinterpret_cast<char*>(&student), sizeof(student)))
                    {
                        if (strcmp(student.full_name_s, name) == 0)
                        {
                            cout << "\nRecord Found";
                            cout << "\nStudent Name: " << student.full_name_s;
                        }
                        else
                        {
                            tempfile.open("temp.txt", ios::out | ios::app | ios::binary);
                            tempfile.write(reinterpret_cast<char*>(&student), sizeof(student));
                            tempfile.close();
                        }
                    }
                }
            }
            class102.close();
            remove("class_102.txt");
            rename("temp.txt", "class_102.txt");
            break;

        }
        case 3: {

            cout << "\nPlease enter the name of student you want to delete: ";
            cin.ignore();
            cin.getline(name, 50);

            class103.open("class_103.txt", ios::in | ios::out | ios::binary);
            if (class103.is_open())
            {
                while (!class103.eof())
                {
                    while (class103.read(reinterpret_cast<char*>(&student), sizeof(student)))
                    {
                        if (strcmp(student.full_name_s, name) == 0)
                        {
                            cout << "\nRecord Found";
                            cout << "\nStudent Name: " << student.full_name_s;
                        }
                        else
                        {
                            tempfile.open("temp.txt", ios::out | ios::app | ios::binary);
                            tempfile.write(reinterpret_cast<char*>(&student), sizeof(student));
                            tempfile.close();
                        }
                    }
                }
            }
            class103.close();
            remove("class_103.txt");
            rename("temp.txt", "class_103.txt");
            break;

        }
        case 4: {
            delete_done = true;
            student_screen();
            break;
        }

        default:cout << "\nInvalid choice, please enter correct number...";
            break;
        }

    } while (!delete_done);

}


void displayStudent()
{
    
    int choice;
    bool display_done = false;

    do
    {
        line();
        cout << "\n\tWELCOME TO STUDENT RECORD DETAIL";
        line();
        cout << "\n\t1. Class 101";
        cout << "\n\t2. Class 102";
        cout << "\n\t3. Class 103";
        cout << "\n\t4. Return to previous page\n";
        cout << "Please enter your choice: ";
        cin >> choice;

        switch (choice)
        {
        case 1: {

            class101.open("class_101.txt", ios::in | ios::binary);
            cout << "\n\t\t\tAll Student Record in Class 101\n";

            if (class101.is_open())
            {
                string line;
                while (getline(class101, line))
                {
                    cout << line << endl;

                }
                _getch();
                class101.close();
            }

            break;
        }
        case 2: {

            class102.open("class_102.txt", ios::in | ios::binary);
            cout << "\n\t\t\tAll Student Record in Class 101\n";

            if (class102.is_open())
            {
                string line;
                while (getline(class102, line))
                {
                    cout << line << endl;
                }
                _getch();
                class102.close();
            }
            break;
        }
        case 3: {
            class103.open("class_103.txt", ios::in | ios::binary);
            cout << "\n\t\t\tAll Student Record in Class 101\n";

            if (class103.is_open())
            {
                string line;
                while (getline(class103, line))
                {
                    cout << line << endl;
                }
                _getch();
                class103.close();
            }

            break;
        }
        case 4: {
            display_done = true;
            student_screen();
            break;
        }
        default:cout << "\nPlease enter correct choice\n";
            break;
        }

    } while (!display_done);
}

string LearningProgress(int score)
{
    if (score >= 80)
    {
        return "EXCELLENT ";
    }
    else if (score < 50)
    {
        return "POOR ";
    }
    else
    {
        return "Progressing";
    }
}


void parent_screen()
{
    int choice = 0;

    do
    {
        line();
        cout << "\n\t1. New Parent Registration";
        cout << "\n\t2. Parent Login";
        line();
        cout << "\nEnter your choice? ";
        cin >> choice;
        switch (choice)
        {
        case 1: {
            register_p(); break;
        }
        case 2: {
            login_p(); break;
        }
        default:cout << "Please enter choice 1 or 2 ?\n";
            break;
        }
    } while (choice == 1 || choice == 2);

}

void register_p()
{
    line();
    cout << "\t\t\tHello! Welcome to the Parent registration process";
    line();

    ofstream ParentFile;
    //open file to write
    ParentFile.open("Parent.txt", ios::out | ios::app | ios::binary);

    if (ParentFile.is_open())
    {
        cin.ignore();
        cout << "\n\tWhat your full name? ";
        cin.getline(newParent.full_name_p, 50);
        cout << "\tWhat your Gender? ";
        cin >> newParent.gender_p;
        cout << "\tWhat your Date of Birth? ";
        cin >> newParent.dob_p;
        cout << "\tWhat your Email address?";
        cin >> newParent.email_p;
        cout << "\tWhat your Contact Number? ";
        cin >> newParent.contact_no_p;
        cin.ignore();
        cout << "\tWhat your Child Name? ";
        cin.getline(newParent.child_name_p, 50);
        cout << "\tAdditional Caregiver Name? ";
        cin.getline(newParent.caregiver_name_p, 50);
        cout << "\tEmergency Contact Number?";
        cin >> newParent.emergency_no_p;
        cin.ignore();
        cout << "\tEnter your username? ";
        cin >> newParent.username_p;
        cout << "\tEnter your password? ";
        cin >> newParent.password_p;

        ParentFile << newParent.full_name_p << endl;
        ParentFile << newParent.gender_p << endl;
        ParentFile << newParent.dob_p << endl;
        ParentFile << newParent.email_p << endl;
        ParentFile << newParent.contact_no_p << endl;
        ParentFile << newParent.child_name_p << endl;
        ParentFile << newParent.caregiver_name_p << endl;
        ParentFile << newParent.emergency_no_p << endl;
        ParentFile << newParent.username_p << endl;
        ParentFile << newParent.password_p << endl;
    }

    ParentFile.close();
    line();
    cout << "\tRegistration Successful!";
    line();
    parent_dash();
}

void login_p()
{

    char usernameSearch_p[20];
    char passwordSearch_p[20];
    int i = 0;
    bool isFound = false;
    do
    {
        cout << "\nEnter your username: ";
        cin >> usernameSearch_p;
        cout << "Enter your password: ";
        cin >> passwordSearch_p;

        ifstream ParentFile;
        ParentFile.open("Parent.txt", ios::in | ios::binary);

        if (ParentFile.is_open())
        {

            while (!ParentFile.eof())
            {
                ParentFile.getline(newParent.username_p, 20);
                ParentFile.getline(newParent.password_p, 20);

                if (strcmp(newParent.username_p, usernameSearch_p) == 0 && strcmp(newParent.password_p, passwordSearch_p) == 0)
                {
                    isFound = true;
                    parent_dash();
                    break;
                }
                else
                {
                    isFound = false;
                }
            }
        }
        if (isFound == false && i < 2)
        {
            cout << " Sorry Invalid username and password\n";
            _getch();
        }
        i++;
        ParentFile.close();

    } while (i < 3);

    if (i == 3 && isFound == false)
    {
        cout << "\nPlease try again later...\n";
        line();
        main();
    }

}

void parent_dash()
{
    int option;
    bool parent_done = false;

    do
    {
        line();
        cout << "\tWelcome to Parent DashBoard";
        line();
        cout << "\n\t1) View Children Report";
        cout << "\n\t2) View School Notice";
        cout << "\n\t3) Return  Main Menu";
        cout << "\n\tEnter your choice: ";
        cin >> option;

        switch (option)
        {
        case 1: {

            break;
        }
        case 2: {
            school_notice();
            break;
        }
        case 3: {
            parent_done = true;
            main();
        }
        default:cout << "\nInvalid option" << endl;
            break;
        }

    } while (!parent_done);

}


void school_notice()
{

    line();
    cout << "\n\tSCHOOL LATEST EVENTS LIST";
    line();
    cout << "\tSWIMMING DAY: 12 September 2022";
    cout << "\tDANCING DAY: 19 September 2022";
    cout << "\n\t SPORTS DAY : 22 September 2022";
    cout << "\n\t PARENTS DAY : 27 September 2022";
    line();

}

void admin_screen()
{
    string Admin_Password;
    string Admin_Attempt;
    Admin_Password = "Password01";

    line();
    cout << "\t\t\tAdmin Login Page";
    line();

    cout << "Password: ";
    cin >> Admin_Attempt;

    if (Admin_Attempt == Admin_Password)
    {
        Admin_Dash();
    }
    else
    {
        cout << "Incorrect Password";
        _getch();
        main_menu();
    }

}

void Admin_Dash()
{
    int option;
    line();
    cout << "\n\tWelcome Admin";
    line();

    cout << "\n1) View Class Records";
    cout << "\n2) View Parent Records";
    cout << "\n3) View Student Page";
    cout << "\n4) Create Report";
    cout << "\nEnter your choice: ";
    cin >> option;

    switch (option)
    {
    case 1: {
        displayStudent();
        break;
    }
    case 2: {
        Parent_Page();
        break;
    }
    case 3: {
        student_screen();
        break;
    }
    case 4: {
        report();
        break;
    }
    default:cout << "\nInvalid option";

        break;
    }
}

void Class_Records()
{
    int option;
    system("CLS");
    line();
    cout << "Welcome to Class Record !" << endl;
    cout << "\n\t1) View Details";
    cout << "\n\t2) Edit Student Records";
    line();

    cout << "\nEnter your choice: ";
    cin >> option;

    switch (option)
    {
    case 1: {
        displayStudent();
        break;
    }
    case 2: {
        editStudent(search_name);
        break;
    }
    default:cout << "\nInvalid option";
        _getch();
        system("CLS");
        break;
    }

}

void Parent_Page()
{

    ParentFile.open("parent.txt", ios::in | ios::binary);
    cout << "\n\t\t\tAll Parent Record\n";

    if (ParentFile.is_open())
    {
        string line;
        while (getline(ParentFile, line))
        {
            cout << line << endl;

        }
        _getch();
        ParentFile.close();
    }
}


void report()
{
    int choice;
    system("CLS");
    cout << "Student Report Sheet";

    cout << "What class is the student from?";
    cout << "\n1. Class 101";
    cout << "\n2. Class 102";
    cout << "\n3. Class 103";
    cout << "Please enter your choice: ";
    cin >> choice;

    switch (choice)
    {
    case 1: {

        class101.open("class_101.txt", ios::in | ios::binary);
        cout << "\n\t\t\tAll Student Record in Class 101\n";

        if (class101.is_open())
        {
            string line;
            while (getline(class101, line))
            {
                cout << line << endl;
            }
            _getch();
            class101.close();
        }

        break;
    }
    case 2: {

        class102.open("class_102.txt", ios::in | ios::binary);
        cout << "\n\t\t\tAll Student Record in Class 101\n";

        if (class102.is_open())
        {
            string line;
            while (getline(class102, line))
            {
                cout << line << endl;
            }
            _getch();
            class102.close();
        }
        break;
    }
    case 3: {
        class103.open("class_103.txt", ios::in | ios::binary);
        cout << "\n\t\t\tAll Student Record in Class 101\n";

        if (class103.is_open())
        {
            string line;
            while (getline(class103, line))
            {
                cout << line << endl;
            }
            _getch();
            class103.close();
        }

        break;
    }


    default:cout << "\nPlease enter correct choice\n";
        _getch();
        system("CLS");
        break;
    }
}

